import {page} from "@playwright/test"

export class LoginPage
{
    constructor(page)
    {
        this.page=page;
        this.usernameField= page.getByRole('textbox', { name: 'Enter Email' })
        this.passwordField= page.getByPlaceholder('Enter Password')
        this.loginButton= page.getByRole('button', { name: 'Sign in' })
        this.newUserSignUpLink= page.getByRole('link', { name: 'New user? Signup' })
        this.errorMessage= page.locator(".errorMessage")
    }

    async loginToApplication(username, Password)
    {
        await this.usernameField.fill(username);
        await this.passwordField.fill(Password);
        await this.loginButton.click()
    }

    async clickOnNewUserSignUpLink()
    {
        await this.newUserSignUpLink.click()
    }

    async getErrorMessage()
    {
        return await this.errorMessage.textContent();
    }
        
    

}