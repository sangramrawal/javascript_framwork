import {test, expect} from "@playwright/test"
import {LoginPage} from "../../pages/LoginPage.js"
import { DashboardPage } from "../../pages/DashboadPage.js";
import user from "../../testdata/user.json"

test("Login to Application", async({page})=>
{
    await page.goto("/login")
    
    const loginPage = new LoginPage(page);
    
    await loginPage.loginToApplication(user.username, user.password);

    const dashboradPage = new DashboardPage(page);

    await dashboradPage.clickOnMenuIcon();
    await dashboradPage.clickOnSignOutButton();


})