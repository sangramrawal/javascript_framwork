export class DashboardPage
{
    constructor (page)
    {
        this.page=page;

        this.menuIcon= page.getByRole('img', { name: 'menu' });
        this.signOutButton= page.getByRole('button', { name: 'Sign out' })

    }

    async clickOnMenuIcon()
    {
        await this.menuIcon.click();

    }

    async clickOnSignOutButton()
    {
        await this.signOutButton.click();
    }
}